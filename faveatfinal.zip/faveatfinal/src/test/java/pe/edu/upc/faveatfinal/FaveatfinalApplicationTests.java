package pe.edu.upc.faveatfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaveatfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
